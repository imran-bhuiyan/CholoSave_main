<?php
require 'vendor/autoload.php';
require 'db.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Http\HttpServer;
use Ratchet\Server\IoServer;
use Ratchet\WebSocket\WsServer;

class Chat implements MessageComponentInterface {
    protected $clients;
    protected $clientGroups; // Track which client belongs to which group

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->clientGroups = []; // Array to store client -> group mappings
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }

   public function onMessage(ConnectionInterface $from, $msg) {
    global $conn;
    $data = json_decode($msg, true);

    // If this is a group registration message
    if (isset($data['type']) && $data['type'] === 'register') {
        // Store the group_id associated with the client
        $this->clientGroups[$from->resourceId] = $data['group_id'];
        return;
    }

    // Save the message to the database
    $stmt = $conn->prepare("INSERT INTO messages (group_id, user_id, message) VALUES (?, ?, ?)");
    if (!$stmt) {
        echo "Database error: " . $conn->error . "\n";
        return;
    }

    $stmt->bind_param("iis", $data['group_id'], $data['user_id'], $data['message']);
    $stmt->execute();
    $stmt->close();

    // Broadcast the message to all clients in the same group
    foreach ($this->clients as $client) {
        if (isset($this->clientGroups[$client->resourceId]) && $this->clientGroups[$client->resourceId] === $data['group_id']) {
            // Only send the message to clients in the same group
            $client->send($msg);
        }
    }
}


    public function onClose(ConnectionInterface $conn) {
        // Remove group mapping when client disconnects
        if (isset($this->clientGroups[$conn->resourceId])) {
            unset($this->clientGroups[$conn->resourceId]);
        }
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    8080
);

echo "WebSocket server running on ws://localhost:8080\n";
$server->run();