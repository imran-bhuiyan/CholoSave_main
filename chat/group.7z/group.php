<?php
session_start();
// Start the session as the first line
$user_id = $_SESSION['user_id'];
$group_id = $_SESSION['group_id'];


if (isset($_SESSION['group_id']) && isset($_SESSION['user_id'])) {
    $group_id = $_SESSION['group_id'];
    $user_id = $_SESSION['user_id'];
    echo 'This is group id: ' . htmlspecialchars($group_id, ENT_QUOTES, 'UTF-8');
    echo 'This is user id: ' . htmlspecialchars($user_id, ENT_QUOTES, 'UTF-8');
} else {
    echo 'Group ID is not set in the session.';
}

if (!isset($conn)) {
    include 'db.php'; // Ensure database connection
}



// Fetch user name from the database if not in the session
$sql = "SELECT name FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    // If the user does not exist, handle the error
    echo "User not found.";
    exit();
}

$user_name = $user['name'];

// Fetch group messages
$sql = "SELECT messages.*, users.name 
        FROM messages 
        JOIN users ON messages.user_id = users.id 
        WHERE group_id = ? 
        ORDER BY created_at ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $group_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col">
            <!-- Header Section -->
            <header class="bg-blue-500 text-white p-6">
                <h1 class="text-3xl font-semibold">Group Chat</h1>
            </header>

            <!-- Chat container -->
            <div class="flex-1 p-6 bg-white rounded-lg shadow-lg m-6">
                <!-- Chat messages area -->
                <div id="messages" class="h-[600px] overflow-y-auto p-6 space-y-4">
                    <?php foreach ($messages as $message): ?>
                        <div
                            class="flex items-start <?= $message['user_id'] === $user_id ? 'justify-end' : '' ?> space-x-2 mb-4">
                            <div class="flex-1 <?= $message['user_id'] === $user_id ? 'flex justify-end' : '' ?>">
                                <div
                                    class="<?= $message['user_id'] === $user_id ? 'bg-blue-500' : 'bg-gray-100' ?> rounded-lg p-3 max-w-[80%] inline-block">
                                    <div
                                        class="font-medium <?= $message['user_id'] === $user_id ? 'text-white' : 'text-gray-900' ?> mb-1">
                                        <?= htmlspecialchars($message['user_id'] === $user_id ? 'You' : $message['name']) ?>
                                    </div>
                                    <p class="<?= $message['user_id'] === $user_id ? 'text-white' : 'text-gray-700' ?>">
                                        <?= htmlspecialchars($message['message']) ?>
                                    </p>
                                    <span
                                        class="text-xs <?= $message['user_id'] === $user_id ? 'text-blue-100' : 'text-gray-500' ?> mt-1 block">
                                        <?= date('h:i A', strtotime($message['created_at'])) ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Message input area -->
                <div class="border-t p-4">
                    <form id="messageForm" class="flex items-end space-x-4">
                        <div class="flex-1">
                            <textarea name="message"
                                class="w-full border rounded-lg p-3 focus:outline-none focus:border-blue-500 resize-none"
                                rows="3" placeholder="Type your message..."></textarea>
                        </div>
                        <button type="submit"
                            class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium">
                            Send
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const groupId = <?php echo json_encode($group_id); ?>;
        const userId = <?php echo json_encode($user_id); ?>;
        const userName = <?php echo json_encode($user_name); ?>; // Include user name

        const socket = new WebSocket('ws://localhost:8080');

// Keep track of connection status
let isConnected = false;

socket.onopen = function() {
    console.log('Connected to WebSocket server');
    isConnected = true;
    
    // Register the client with the group ID
    socket.send(JSON.stringify({
        type: 'register',
        group_id: groupId
    }));
};

socket.onclose = function() {
    console.log('Disconnected from WebSocket server');
    isConnected = false;
    
    // Attempt to reconnect after 3 seconds
    setTimeout(function() {
        if (!isConnected) {
            console.log('Attempting to reconnect...');
            socket = new WebSocket('ws://localhost:8080');
        }
    }, 3000);
};

socket.onerror = function(error) {
    console.error('WebSocket Error:', error);
};

socket.onmessage = function(event) {
    try {
        const data = JSON.parse(event.data);
        
        // Only process messages for the current group
        if (data.group_id === groupId) {
            const messagesDiv = document.getElementById('messages');
            const messageElem = document.createElement('div');
            
            // Sanitize the message content
            const sanitizeHTML = (str) => {
                const temp = document.createElement('div');
                temp.textContent = str;
                return temp.innerHTML;
            };
            
            const sanitizedMessage = sanitizeHTML(data.message);
            const sanitizedName = sanitizeHTML(data.user_id === userId ? 'You' : data.name);
            
            messageElem.classList.add('flex', 'items-start', data.user_id === userId ? 'justify-end' : '', 'space-x-2', 'mb-4');
            messageElem.innerHTML = `
                <div class="flex-1 ${data.user_id === userId ? 'flex justify-end' : ''}">
                    <div class="${data.user_id === userId ? 'bg-blue-500' : 'bg-gray-100'} rounded-lg p-3 max-w-[80%] inline-block">
                        <div class="font-medium ${data.user_id === userId ? 'text-white' : 'text-gray-900'} mb-1">
                            ${sanitizedName}
                        </div>
                        <p class="${data.user_id === userId ? 'text-white' : 'text-gray-700'}">
                            ${sanitizedMessage}
                        </p>
                        <span class="text-xs ${data.user_id === userId ? 'text-blue-100' : 'text-gray-500'} mt-1 block">
                            ${new Date().toLocaleTimeString()}
                        </span>
                    </div>
                </div>
            `;
            
            messagesDiv.appendChild(messageElem);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
    } catch (error) {
        console.error('Error processing message:', error);
    }
};

// Message form submission
document.getElementById('messageForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const messageInput = this.querySelector('textarea[name="message"]');
    const message = messageInput.value.trim();
    
    if (message !== '' && isConnected) {
        const msgData = {
            group_id: groupId,
            user_id: userId,
            name: userName,
            message: message,
            timestamp: new Date().toISOString()
        };
        
        // Send message to WebSocket server
        socket.send(JSON.stringify(msgData));
        
        // Clear input field
        messageInput.value = '';
    } else if (!isConnected) {
        alert('Unable to send message. Please check your connection.');
    }
});

    </script>
</body>

</html>